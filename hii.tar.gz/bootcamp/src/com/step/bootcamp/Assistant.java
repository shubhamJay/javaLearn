package com.step.bootcamp;

public class Assistant implements Listeners{
  @Override
  public void actionForFull() {
    System.out.println("No space");
  }

  @Override
  public void actionForAvailable() {
    System.out.println("No space");
  }
}
