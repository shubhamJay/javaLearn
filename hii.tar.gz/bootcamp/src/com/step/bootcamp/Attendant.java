package com.step.bootcamp;

import java.util.ArrayList;

//understands to manage parking lot(s);

public class Attendant implements Listeners{

  private ArrayList<ParkingLot> parkingLots;
  private Assistant assistant;

  public Attendant() {
    this.parkingLots = new ArrayList<>();
  }

  public boolean manage(ParkingLot parkingLot) {
    parkingLot.addListener(this);
    return parkingLots.add(parkingLot);
  }

  public Object park(Vehicle vehicle) {
    for (ParkingLot parkingLot : parkingLots) {
      if (!parkingLot.isFull()) {
        return parkingLot.park(vehicle);
      }
    }
    throw new UnableToParkException("No space Available");
  }

  public Vehicle checkout(Object token) throws InvalidTokenException {
    for (ParkingLot parkingLot : parkingLots) {
      if (parkingLot.hasVehicleFor(token)) {
        return parkingLot.checkout(token);
      }
    }
    throw new InvalidTokenException();
  }

  public void addAssistant(Assistant assistant){
    this.assistant = assistant;
    for (ParkingLot parkingLot : parkingLots) {
      parkingLot.addListener(this.assistant);
    }
  }

  @Override
  public void actionForFull() {
    System.out.println("full");
  }

  @Override
  public void actionForAvailable() {
    System.out.println("Not full");
  }
}
