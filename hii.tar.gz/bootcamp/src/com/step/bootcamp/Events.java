package com.step.bootcamp;

import java.util.ArrayList;

public class Events {

  private ArrayList<Listeners> listeners;

  public Events() {
    this.listeners = new ArrayList<>();
  }

  public void addListener(Listeners listener) {
    this.listeners.add(listener);
  }

  public void fireEventForFull(){
    for (Listeners listener : listeners) {
      listener.actionForFull();
    }
  }
  public void fireEventForAvailable(){
    for (Listeners listener : listeners) {
      listener.actionForAvailable();
    }
  }
}
