package com.step.bootcamp;

public class InvalidTokenException extends Throwable {
  public InvalidTokenException() {
    super("Invalid token!");
  }
}
