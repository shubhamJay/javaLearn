package com.step.bootcamp;

public interface Listeners {
  void actionForFull();
  void actionForAvailable();
}
