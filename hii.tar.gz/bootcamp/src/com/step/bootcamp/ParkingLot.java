package com.step.bootcamp;

import java.util.HashMap;

// understands a place to park vehicles;

public class ParkingLot extends Events {
  private final HashMap<Object,Vehicle> vehicles;
  private final int capacity;

  public ParkingLot(int capacity) {
    vehicles = new HashMap<>();
    this.capacity = capacity;
  }

  public Object park(Vehicle car) throws UnableToParkException {
    if(hasVehicle(car)) {
      throw new UnableToParkException("Vehicle already parked!");
    }
    if(isFull()) {
      throw new UnableToParkException("No space available");
    }
    Object key = new Object();
    vehicles.put(key,car);
    if (isFull()) fireEventForFull();
    return key;
  }

  private boolean hasVehicle(Vehicle vehicle) {
    return vehicles.containsValue(vehicle);
  }

  public boolean hasVehicleFor(Object token) {
    return vehicles.containsKey(token);
  }

  public Vehicle checkout(Object token) throws InvalidTokenException {
    if (!vehicles.containsKey(token)) {
      throw new InvalidTokenException();
    }
    //: todo should give alert when parking is full before checking out a vehicle
      fireEventForAvailable();
      return vehicles.remove(token);
  }

  public boolean isFull() {
    return vehicles.size() == capacity;
  }

}
