package com.step.bootcamp;

public class UnableToParkException extends RuntimeException {
  public UnableToParkException(String message) {
    super(message);
  }
}
