package com.step.bootcamp;

public interface Vehicle {
}
