package com.step.bootcamp;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.junit.Assert.*;
import static org.mockito.Mockito.calls;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

//ensures that attendant manages lots in expected manner

public class AttendantTest {



  private Attendant attendant;


  private class TestCar implements Vehicle {
  }


    ParkingLot mockedParkingLot = mock(ParkingLot.class);

  @Before
  public void setUp() throws Exception {
    attendant = new Attendant();
  }

  @Test
  public void shouldBeAbleToManageParkingLot() {
    ParkingLot firstParkingLot = new ParkingLot(2);
    assertTrue(attendant.manage(firstParkingLot));
  }

  @Test
  public void shouldParkVehicleIntoParking() throws Exception {
    ParkingLot firstParkingLot = new ParkingLot(2);
    attendant.manage(firstParkingLot);
    Object token =  attendant.park(new TestCar());
    assertNotNull(token);
  }

  @Test
  public void shouldBeAbleToParkWhenFirstParkingLotIsFull() throws Exception {
    ParkingLot firstParkingLot = new ParkingLot(1);
    ParkingLot secondParkingLot = new ParkingLot(1);
    attendant.manage(firstParkingLot);
    attendant.manage(secondParkingLot);
    attendant.park(new TestCar());
    Object tokenForSecond =  attendant.park(new TestCar());
    assertNotNull(tokenForSecond);
  }

  @Test(expected = UnableToParkException.class)
  public void shouldThrowExceptionWhenNoSpaceAvailable() throws Exception {
    ParkingLot firstParkingLot = new ParkingLot(1);
    ParkingLot secondParkingLot = new ParkingLot(1);
    attendant.manage(firstParkingLot);
    attendant.manage(secondParkingLot);
    attendant.park(new TestCar());
    attendant.park(new TestCar());
    attendant.park(new TestCar());
  }

  @Test
  public void shouldBeAbleToCheckoutAPreviouslyParkedVehicle() throws InvalidTokenException {
    ParkingLot parkingLot = new ParkingLot(2);
    attendant.manage(parkingLot);
    TestCar testCar = new TestCar();
    Object token = attendant.park(testCar);
    Vehicle checkedoutCar = attendant.checkout(token);
    assertEquals(testCar,checkedoutCar);
  }

  @Test(expected = InvalidTokenException.class)
  public void shouldThrowExceptionForInvalidToken() throws InvalidTokenException {
    ParkingLot parkingLot = new ParkingLot(2);
    attendant.manage(parkingLot);
    Object invalidToken = new Object();
    attendant.checkout(invalidToken);
  }

  @Test
  public void shouldAddAttendentItselAsListenerToAllParkingLots() {
    Assistant assistant = new Assistant();
    attendant.manage(mockedParkingLot);
//    verify(attendant).addAssistant(assistant);
//    assertThat(testLot.testListeners,hasItem(attendant));
  }

//  @Test
//  public void shouldAddAssistantAsListenerToAllParkingLots() {
//    ParkingLot parkingLot = new TestParkingLot(2);
//    Assistant assistant = new Assistant();
//    attendant.manage(parkingLot);
//    attendant.addAssistant(assistant);
//    TestParkingLot testLot = (TestParkingLot) parkingLot;
//    assertThat(testLot.testListeners,hasItem(assistant));
//  }
}