package com.step.bootcamp;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

public class ParkingLotTest {
  private ParkingLot parkingLot;
  private TestCar testCar;

  private class TestCar implements Vehicle{ }

  private class TestListener implements Listeners {

    public boolean isActionForFullPerformed;
    private boolean isActionForAvailablePerformed;

    public TestListener() {
      this.isActionForFullPerformed =  false;
      this.isActionForAvailablePerformed =  false;
    }

    @Override
    public void actionForFull() {
      isActionForFullPerformed = true;
    }

    @Override
    public void actionForAvailable() {
      isActionForAvailablePerformed = true;
    }
  }

  @Before
  public void setUp() {
    parkingLot = new ParkingLot(2);
    testCar = new TestCar();
  }

  @Test
  public void shouldBeAbleParkACar() throws UnableToParkException {
    Object token = parkingLot.park(testCar);
    assertNotNull(token);
    assertTrue(parkingLot.hasVehicleFor(token));
  }

  @Test
  public void shouldCheckoutTheCarOfGivenNumber() throws UnableToParkException, InvalidTokenException {
    Object token = parkingLot.park(testCar);
    assertThat(parkingLot.checkout(token), is(testCar));
  }

  @Test
  public void checkedOutCarShouldNotPresent() throws UnableToParkException, InvalidTokenException {
    Object token = parkingLot.park(testCar);
    parkingLot.checkout(token);
    assertFalse(parkingLot.hasVehicleFor(token));
  }

  @Test(expected = UnableToParkException.class)
  public void shouldNotAllowToParkSameCarTwice() throws UnableToParkException {
    parkingLot.park(testCar);
    parkingLot.park(testCar);
  }

  @Test(expected = InvalidTokenException.class)
  public void shouldThrowExceptionWhenCarIsNotPresent() throws InvalidTokenException {
    parkingLot.checkout(123);
  }

  @Test(expected = InvalidTokenException.class)
  public void shouldNotAllowToCheckOutSameCarTwice() throws InvalidTokenException {
    Object token = parkingLot.park(testCar);
    parkingLot.checkout(token);
    parkingLot.checkout(token);
  }

  @Test
  public void shouldGiveFalseWhenParkingIsNotFull() {
    assertFalse(parkingLot.isFull());
  }

  @Test
  public void shouldGiveTrueWhenParkingIsFull() throws UnableToParkException {
    parkingLot.park(testCar);
    parkingLot.park(new TestCar());
    assertTrue(parkingLot.isFull());
  }

  @Test(expected = UnableToParkException.class)
  public void shouldNotAllowToParkVehicleWhenCapacityIsFull() throws UnableToParkException {
    parkingLot.park(testCar);
    parkingLot.park(new TestCar());
    parkingLot.park(new TestCar());
  }

  @Test
  public void shouldReturnLiveParkingLotStatus() throws UnableToParkException, InvalidTokenException {
    Object tokenForFirst = parkingLot.park(testCar);
    parkingLot.park(new TestCar());
    assertTrue(parkingLot.isFull());
    parkingLot.checkout(tokenForFirst);
    assertFalse(parkingLot.isFull());
  }

  @Test
  public void shouldCallActionForFullOfAllListeners() {
    ParkingLot parkingLot = new ParkingLot(1);
    TestListener firstTestListener = new TestListener();
    TestListener secondTestListener = new TestListener();
    parkingLot.addListener(firstTestListener);
    parkingLot.addListener(secondTestListener);
    parkingLot.park(new TestCar());
    assertTrue(firstTestListener.isActionForFullPerformed);
    assertTrue(secondTestListener.isActionForFullPerformed);
  }

  @Test
  public void shouldCallActionForAvailableOfAllListeners() throws InvalidTokenException {
    ParkingLot parkingLot = new ParkingLot(1);
    TestListener firstTestListener = new TestListener();
    TestListener secondTestListener = new TestListener();
    parkingLot.addListener(firstTestListener);
    parkingLot.addListener(secondTestListener);
    Object token = parkingLot.park(new TestCar());
    assertTrue(firstTestListener.isActionForFullPerformed);
    assertTrue(secondTestListener.isActionForFullPerformed);
    parkingLot.checkout(token);
    assertTrue(firstTestListener.isActionForAvailablePerformed);
    assertTrue(secondTestListener.isActionForAvailablePerformed);
  }
}
