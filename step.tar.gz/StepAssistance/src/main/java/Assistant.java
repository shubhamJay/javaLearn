import java.util.HashMap;
import java.util.Stack;

//  private Appliance lightController;

public class Assistant {

  private HashMap<String, Command> commands;
  private Stack<Command> previousActions;

  public Assistant() {
    this.commands = new HashMap<>();
    this.previousActions = new Stack<>();
  }

  public void add(String key, Command command) {
    commands.put(key, command);
  }

  public void listen(String actionToPerform) {
    if (actionToPerform == "undo" && !previousActions.isEmpty()) {
      previousActions.pop().undo();
      return;
    }
    if (actionToPerform == null || commands.get(actionToPerform) == null) return;
    Command lastAction = commands.get(actionToPerform);
    lastAction.execute();
    previousActions.add(lastAction);
  }
}
