public class CircularLight {

  public boolean switchOn() {
    return true;
  }

  public boolean switchOff() {
    return true;
  }
}
