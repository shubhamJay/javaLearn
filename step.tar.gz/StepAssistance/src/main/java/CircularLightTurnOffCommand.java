public class CircularLightTurnOffCommand implements Command{
  private final CircularLight circularLight;

  public CircularLightTurnOffCommand(CircularLight circularLight) {
    this.circularLight = circularLight;
  }

  @Override
  public void execute() {
    circularLight.switchOff();
  }

  @Override
  public void undo() {
    circularLight.switchOn();
  }
}
