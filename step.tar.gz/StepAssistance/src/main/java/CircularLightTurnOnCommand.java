public class CircularLightTurnOnCommand implements Command{
  private final CircularLight circularLight;

  public CircularLightTurnOnCommand(CircularLight circularLight) {
    this.circularLight = circularLight;
  }

  @Override
  public void execute() {
    circularLight.switchOn();
  }
  @Override
  public void undo() {
    circularLight.switchOff();
  }
}
