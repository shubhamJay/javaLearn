public class HomeTheater{
  private static final int MIN = 0;
  private static final int MAX = 5;
  private int volume = 0;

  public boolean on() {
    return true;
  }

  public boolean off() {
    return true;
  }

  public boolean play() {
    return true;
  }

  public boolean volumeUp() {
    if (volume < MAX) {
      ++this.volume;
      System.out.println(volume);
      return true;
    }
    return false;
  }

  public boolean volumeDown() {
    if (volume > MIN) {
      --this.volume;
      return true;
    }
    return false;
  }

  public boolean fullVolume(){
    volume = MAX;
    return true;
  }

  public boolean mute() {
    volume = MIN;
    return true;
  }

  public boolean pause(){
    return true;
  }
}
