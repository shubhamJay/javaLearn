public class Light {

  public boolean turnOn() {
    return true;
  }

  public boolean turnOff() {
    return true;
  }
}
