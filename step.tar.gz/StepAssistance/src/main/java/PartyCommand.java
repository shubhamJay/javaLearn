public class PartyCommand implements Command {
  private final Light light;
  private final CircularLight circularLight;
  private final HomeTheater theater;

  public PartyCommand(Light light, CircularLight circularLight, HomeTheater theater) {
    this.light = light;
    this.circularLight = circularLight;
    this.theater = theater;
  }

  @Override
  public void execute() {
    light.turnOn();
    circularLight.switchOn();
    theater.on();
    theater.fullVolume();
  }

  @Override
  public void undo() {
    theater.off();
    theater.mute();
  }
}
