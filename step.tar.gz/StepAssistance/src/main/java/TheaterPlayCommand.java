public class TheaterPlayCommand implements Command{
  private final HomeTheater theater;

  public TheaterPlayCommand(HomeTheater theater) {
    this.theater = theater;
  }

  @Override
  public void execute() {
    theater.play();
  }

  @Override
  public void undo() {
   theater.pause();
  }

}
