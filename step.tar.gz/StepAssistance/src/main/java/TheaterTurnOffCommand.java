public class TheaterTurnOffCommand implements Command{
  private final HomeTheater theater;

  public TheaterTurnOffCommand(HomeTheater theater) {
    this.theater = theater;
  }

  @Override
  public void execute() {
    theater.off();
  }

  @Override
  public void undo() {
    theater.on();
  }
}
