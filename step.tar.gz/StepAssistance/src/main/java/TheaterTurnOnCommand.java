public class TheaterTurnOnCommand implements Command{
  private final HomeTheater theater;

  public TheaterTurnOnCommand(HomeTheater theater) {
    this.theater = theater;
  }

  @Override
  public void execute() {
    theater.on();
  }

  @Override
  public void undo() {
    theater.off();
  }
}
