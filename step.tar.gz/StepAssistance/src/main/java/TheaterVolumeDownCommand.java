public class TheaterVolumeDownCommand implements Command{
  private final HomeTheater theater;

  public TheaterVolumeDownCommand(HomeTheater theater) {
    this.theater = theater;
  }

  @Override
  public void execute() {
    theater.volumeDown();
  }

  @Override
  public void undo() {

  }
}
