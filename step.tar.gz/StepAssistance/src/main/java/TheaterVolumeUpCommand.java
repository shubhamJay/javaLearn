public class TheaterVolumeUpCommand implements  Command{
  private final HomeTheater theater;

  public TheaterVolumeUpCommand(HomeTheater theater) {
    this.theater = theater;
  }

  @Override
  public void execute() {
    theater.volumeUp();
  }

  @Override
  public void undo() {

  }

}
