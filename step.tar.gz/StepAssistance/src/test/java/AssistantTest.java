import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.*;

public class AssistantTest {

  private Assistant assistant;
  private Light mockedLight;
  private CircularLight mockedCircularLight;
  private HomeTheater mockedTheater;
  private String INVALID_REQUEST = "foo";

  @Before
  public void setUp() throws Exception {
    assistant = new Assistant();
    mockedLight = mock(Light.class);
    mockedCircularLight = mock(CircularLight.class);
    mockedTheater = mock(HomeTheater.class);
  }

  @Test
  public void shouldTurnLightOn() {
    LightTurnOnCommand testTurnOnController = new LightTurnOnCommand(mockedLight);
    assistant.add("turn on", testTurnOnController);
    assistant.listen("turn on");
    verify(mockedLight).turnOn();
  }

  @Test
  public void shouldTurnLightOff() {
    LightTurnOffCommand testTurnOffController = new LightTurnOffCommand(mockedLight);
    assistant.add("turn off", testTurnOffController);
    assistant.listen("turn off");
    verify(mockedLight).turnOff();
  }

  @Test
  public void shouldTurnCircularLightOn() {
    CircularLightTurnOnCommand circularLightTurnOnCommand = new CircularLightTurnOnCommand(mockedCircularLight);
    assistant.add("switch on", circularLightTurnOnCommand);
    assistant.listen("switch on");
    verify(mockedCircularLight).switchOn();
  }

  @Test
  public void shouldTurnCircularLightOff() {
    CircularLightTurnOffCommand circularLightTurnOffCommand = new CircularLightTurnOffCommand(mockedCircularLight);
    assistant.add("switch off", circularLightTurnOffCommand);
    assistant.listen("switch off");
    verify(mockedCircularLight).switchOff();
  }

  @Test
  public void shouldTurnTheaterOn() {
    TheaterTurnOnCommand theaterTurnOnCommand = new TheaterTurnOnCommand(mockedTheater);
    assistant.add("music on", theaterTurnOnCommand);
    assistant.listen("music on");
    verify(mockedTheater).on();
  }

  @Test
  public void shouldTurnTheaterOff() {
    TheaterTurnOffCommand theaterTurnOffCommand = new TheaterTurnOffCommand(mockedTheater);
    assistant.add("music off", theaterTurnOffCommand);
    assistant.listen("music off");
    verify(mockedTheater).off();
  }

  @Test
  public void shouldPlayMusic() {
    TheaterPlayCommand theaterPlayCommand = new TheaterPlayCommand(mockedTheater);
    assistant.add("play music", theaterPlayCommand);
    assistant.listen("play music");
    verify(mockedTheater).play();
  }

  @Test
  public void shouldIncreaseVolumeOfTheater() {
    TheaterVolumeUpCommand theaterVolumeUpCommand = new TheaterVolumeUpCommand(mockedTheater);
    assistant.add("volume up", theaterVolumeUpCommand);
    assistant.listen("volume up");
    verify(mockedTheater).volumeUp();
  }

  @Test
  public void shouldDecreaseVolumeOfTheater() {
    TheaterVolumeDownCommand theaterVolumeDownCommand = new TheaterVolumeDownCommand(mockedTheater);
    assistant.add("volume down", theaterVolumeDownCommand);
    assistant.listen("volume down");
    verify(mockedTheater).volumeDown();
  }

  @Test
  public void shouldStartParty() {
    PartyCommand partyCommand = new PartyCommand(mockedLight, mockedCircularLight, mockedTheater);
    assistant.add("party", partyCommand);
    assistant.listen("party");
    verify(mockedTheater).fullVolume();
    verify(mockedTheater).on();
    verify(mockedLight).turnOn();
    verify(mockedCircularLight).switchOn();
  }

  @Test
  public void shouldDoNothingIfInvalidListenRequestIsGiven() {
    assistant.listen(INVALID_REQUEST);
  }

  @Test
  public void shouldBeAbleToUndoOfTurnOnLight() {
    LightTurnOnCommand testTurnOnController = new LightTurnOnCommand(mockedLight);
    assistant.add("turn on", testTurnOnController);
    assistant.listen("turn on");
    assistant.listen("undo");
    verify(mockedLight).turnOff();
  }

  @Test
  public void shouldBeAbleToUndoPerformedActions() {
    LightTurnOnCommand testTurnOnController = new LightTurnOnCommand(mockedLight);
    LightTurnOffCommand testTurnOffController = new LightTurnOffCommand(mockedLight);
    TheaterTurnOnCommand theaterTurnOnCommand = new TheaterTurnOnCommand(mockedTheater);
    assistant.add("music on", theaterTurnOnCommand);
    assistant.add("turn off", testTurnOffController);
    assistant.add("turn on", testTurnOnController);
    assistant.listen("turn on");
    assistant.listen("turn off");
    assistant.listen("music on");

    clearInvocations(mockedLight);

    assistant.listen("undo");
    verify(mockedTheater).off();

    assistant.listen("undo");
    verify(mockedLight).turnOn();

    assistant.listen("undo");
    verify(mockedLight).turnOff();
  }
}