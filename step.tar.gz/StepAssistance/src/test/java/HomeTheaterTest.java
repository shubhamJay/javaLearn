import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HomeTheaterTest {

  private HomeTheater homeTheater;

  @Before
  public void setUp() throws Exception {
    homeTheater = new HomeTheater();
  }

  @Test
  public void shouldIncreaseVolume() {
    assertTrue(homeTheater.volumeUp());
  }
  @Test
  public void shouldNotIncreaseVolumeBeyond5() {
    homeTheater.volumeUp();
    homeTheater.volumeUp();
    homeTheater.volumeUp();
    homeTheater.volumeUp();
    homeTheater.volumeUp();
    assertFalse(homeTheater.volumeUp());
  }

  @Test
  public void shouldDecreaseVolume() {
    homeTheater.volumeUp();
    assertTrue(homeTheater.volumeDown());
  }
  @Test
  public void shouldNotDecreaseVolumeBelow0() {
    assertFalse(homeTheater.volumeDown());
  }
}